<?php
/**
 * Plugin Name: BiztoriBD Automation for WooCommerce
 * Plugin URI: https://biztoribbd.com
 * Description: Full workflow automation engine — trigger workflows on WooCommerce events, manage & monitor workflows, track abandonment, sync contacts.
 * Version: 2.0.0
 * Author: BiztoriBD
 * Author URI: https://biztoribbd.com
 * Requires Plugins: woocommerce
 * License: GPL v2 or later
 * Text Domain: biztoribbd
 */

if (!defined('ABSPATH')) exit;

class BiztoriBD_Automation {
    private $api_key;
    private $api_url;

    public function __construct() {
        $this->api_key = get_option('biztoribbd_api_key', '');
        $this->api_url = get_option('biztoribbd_api_url', 'https://euocvkvdixpxfznrduzi.supabase.co/functions/v1/public-api');

        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);

        // AJAX handlers
        add_action('wp_ajax_bz_list_workflows', [$this, 'ajax_list_workflows']);
        add_action('wp_ajax_bz_execute_workflow', [$this, 'ajax_execute_workflow']);
        add_action('wp_ajax_bz_list_executions', [$this, 'ajax_list_executions']);
        add_action('wp_ajax_bz_get_execution', [$this, 'ajax_get_execution']);
        add_action('wp_ajax_bz_workflow_stats', [$this, 'ajax_workflow_stats']);
        add_action('wp_ajax_bz_save_mappings', [$this, 'ajax_save_mappings']);

        if (empty($this->api_key)) return;

        // WooCommerce event hooks
        add_action('woocommerce_new_order', [$this, 'on_new_order'], 10, 2);
        add_action('woocommerce_order_status_completed', [$this, 'on_order_complete']);
        add_action('woocommerce_order_status_failed', [$this, 'on_payment_failed']);
        add_action('woocommerce_order_status_cancelled', [$this, 'on_order_cancelled']);
        add_action('woocommerce_order_status_refunded', [$this, 'on_order_refunded']);
        add_action('woocommerce_created_customer', [$this, 'on_customer_created'], 10, 3);
        add_action('woocommerce_update_product', [$this, 'on_product_updated'], 10, 2);
        add_action('woocommerce_add_to_cart', [$this, 'on_add_to_cart'], 10, 6);
        add_action('wp_footer', [$this, 'inject_tracker_script']);

        // Abandoned cart cron
        add_action('biztoribbd_check_abandoned', [$this, 'check_abandoned_carts']);
        if (!wp_next_scheduled('biztoribbd_check_abandoned')) {
            wp_schedule_event(time(), 'hourly', 'biztoribbd_check_abandoned');
        }
    }

    // ─── Admin Menu ───
    public function add_admin_menu() {
        add_menu_page('BiztoriBD', 'BiztoriBD', 'manage_options', 'biztoribbd', [$this, 'page_dashboard'], 'dashicons-networking', 56);
        add_submenu_page('biztoribbd', 'Dashboard', 'Dashboard', 'manage_options', 'biztoribbd', [$this, 'page_dashboard']);
        add_submenu_page('biztoribbd', 'Workflows', 'Workflows', 'manage_options', 'biztoribbd-workflows', [$this, 'page_workflows']);
        add_submenu_page('biztoribbd', 'Executions', 'Executions', 'manage_options', 'biztoribbd-executions', [$this, 'page_executions']);
        add_submenu_page('biztoribbd', 'Event Mappings', 'Event Mappings', 'manage_options', 'biztoribbd-mappings', [$this, 'page_mappings']);
        add_submenu_page('biztoribbd', 'Settings', 'Settings', 'manage_options', 'biztoribbd-settings', [$this, 'page_settings']);
    }

    public function register_settings() {
        register_setting('biztoribbd_settings', 'biztoribbd_api_key');
        register_setting('biztoribbd_settings', 'biztoribbd_api_url');
        register_setting('biztoribbd_settings', 'biztoribbd_event_mappings');
    }

    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'biztoribbd') === false) return;
        wp_enqueue_style('biztoribbd-admin', plugin_dir_url(__FILE__) . 'admin.css', [], '2.0.0');
        wp_enqueue_script('biztoribbd-admin', plugin_dir_url(__FILE__) . 'admin.js', ['jquery'], '2.0.0', true);
        wp_localize_script('biztoribbd-admin', 'bzAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('biztoribbd_nonce'),
        ]);
    }

    // ─── Admin Pages ───
    public function page_dashboard() {
        $stats = $this->api_get('/stats');
        ?>
        <div class="wrap bz-wrap">
            <h1>BiztoriBD Dashboard</h1>
            <div class="bz-grid">
                <div class="bz-card">
                    <h3>Connection Status</h3>
                    <p class="bz-status <?php echo !empty($this->api_key) ? 'connected' : 'disconnected'; ?>">
                        <?php echo !empty($this->api_key) ? '✓ Connected' : '✗ Not Connected'; ?>
                    </p>
                </div>
                <div class="bz-card">
                    <h3>Total Workflows</h3>
                    <p class="bz-number"><?php echo isset($stats['total_workflows']) ? $stats['total_workflows'] : '—'; ?></p>
                </div>
                <div class="bz-card">
                    <h3>Executions (24h)</h3>
                    <p class="bz-number"><?php echo isset($stats['executions_24h']) ? $stats['executions_24h'] : '—'; ?></p>
                </div>
                <div class="bz-card">
                    <h3>Success Rate</h3>
                    <p class="bz-number"><?php echo isset($stats['success_rate']) ? $stats['success_rate'] . '%' : '—'; ?></p>
                </div>
            </div>
            <div class="bz-card" style="margin-top:20px;">
                <h3>Quick Actions</h3>
                <a href="<?php echo admin_url('admin.php?page=biztoribbd-workflows'); ?>" class="button button-primary">Manage Workflows</a>
                <a href="<?php echo admin_url('admin.php?page=biztoribbd-mappings'); ?>" class="button">Event Mappings</a>
                <a href="<?php echo admin_url('admin.php?page=biztoribbd-executions'); ?>" class="button">View Executions</a>
            </div>
        </div>
        <?php
    }

    public function page_workflows() {
        ?>
        <div class="wrap bz-wrap">
            <h1>Workflows</h1>
            <div id="bz-workflows-list"><p>Loading workflows...</p></div>
        </div>
        <script>
        jQuery(function($) {
            $.post(bzAdmin.ajaxUrl, { action: 'bz_list_workflows', _wpnonce: bzAdmin.nonce }, function(res) {
                if (!res.success) { $('#bz-workflows-list').html('<p class="bz-error">Failed to load workflows.</p>'); return; }
                var html = '<table class="wp-list-table widefat fixed striped"><thead><tr><th>Name</th><th>Status</th><th>Version</th><th>Actions</th></tr></thead><tbody>';
                if (res.data.length === 0) { html += '<tr><td colspan="4">No workflows found.</td></tr>'; }
                res.data.forEach(function(w) {
                    html += '<tr><td>' + w.name + '</td><td>' + (w.is_active ? '<span class="bz-badge active">Active</span>' : '<span class="bz-badge">Inactive</span>') + '</td><td>v' + w.version + '</td><td><button class="button bz-execute" data-id="' + w.id + '">Execute</button></td></tr>';
                });
                html += '</tbody></table>';
                $('#bz-workflows-list').html(html);
                $('.bz-execute').on('click', function() {
                    var id = $(this).data('id');
                    var btn = $(this);
                    btn.prop('disabled', true).text('Running...');
                    $.post(bzAdmin.ajaxUrl, { action: 'bz_execute_workflow', _wpnonce: bzAdmin.nonce, workflow_id: id, input: JSON.stringify({ _source: 'wordpress_manual' }) }, function(r) {
                        btn.prop('disabled', false).text('Execute');
                        alert(r.success ? 'Workflow executed! ID: ' + r.data.execution_id : 'Error: ' + r.data);
                    });
                });
            });
        });
        </script>
        <?php
    }

    public function page_executions() {
        ?>
        <div class="wrap bz-wrap">
            <h1>Execution History</h1>
            <div id="bz-executions-list"><p>Loading executions...</p></div>
        </div>
        <script>
        jQuery(function($) {
            $.post(bzAdmin.ajaxUrl, { action: 'bz_list_executions', _wpnonce: bzAdmin.nonce }, function(res) {
                if (!res.success) { $('#bz-executions-list').html('<p class="bz-error">Failed to load.</p>'); return; }
                var html = '<table class="wp-list-table widefat fixed striped"><thead><tr><th>ID</th><th>Workflow</th><th>Status</th><th>Started</th><th>Duration</th></tr></thead><tbody>';
                if (res.data.length === 0) { html += '<tr><td colspan="5">No executions found.</td></tr>'; }
                res.data.forEach(function(e) {
                    var dur = e.finished_at ? ((new Date(e.finished_at) - new Date(e.started_at)) / 1000).toFixed(1) + 's' : '—';
                    html += '<tr><td><code>' + e.id.substring(0,8) + '</code></td><td>' + (e.workflow_name || e.workflow_id.substring(0,8)) + '</td><td><span class="bz-badge ' + e.status + '">' + e.status + '</span></td><td>' + new Date(e.started_at).toLocaleString() + '</td><td>' + dur + '</td></tr>';
                });
                html += '</tbody></table>';
                $('#bz-executions-list').html(html);
            });
        });
        </script>
        <?php
    }

    public function page_mappings() {
        $mappings = get_option('biztoribbd_event_mappings', []);
        if (!is_array($mappings)) $mappings = [];
        $events = [
            'new_order'        => 'New Order Created',
            'order_complete'   => 'Order Completed',
            'payment_failed'   => 'Payment Failed',
            'order_cancelled'  => 'Order Cancelled',
            'order_refunded'   => 'Order Refunded',
            'customer_created' => 'New Customer Registered',
            'product_updated'  => 'Product Updated',
            'add_to_cart'      => 'Add to Cart',
            'cart_abandon'     => 'Cart Abandoned',
        ];
        ?>
        <div class="wrap bz-wrap">
            <h1>Event → Workflow Mappings</h1>
            <p>Map WooCommerce events to workflows. When the event fires, the mapped workflow executes automatically.</p>
            <form id="bz-mappings-form">
                <table class="wp-list-table widefat fixed striped">
                    <thead><tr><th>Event</th><th>Workflow ID</th></tr></thead>
                    <tbody>
                    <?php foreach ($events as $key => $label): ?>
                        <tr>
                            <td><strong><?php echo $label; ?></strong><br><code><?php echo $key; ?></code></td>
                            <td><input type="text" name="mappings[<?php echo $key; ?>]" value="<?php echo esc_attr($mappings[$key] ?? ''); ?>" class="regular-text" placeholder="Paste workflow ID here"></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <p><button type="submit" class="button button-primary">Save Mappings</button></p>
            </form>
        </div>
        <script>
        jQuery(function($) {
            $('#bz-mappings-form').on('submit', function(e) {
                e.preventDefault();
                var data = $(this).serializeArray();
                var mappings = {};
                data.forEach(function(item) {
                    var key = item.name.replace('mappings[', '').replace(']', '');
                    if (item.value) mappings[key] = item.value;
                });
                $.post(bzAdmin.ajaxUrl, { action: 'bz_save_mappings', _wpnonce: bzAdmin.nonce, mappings: JSON.stringify(mappings) }, function(res) {
                    alert(res.success ? 'Mappings saved!' : 'Error saving mappings.');
                });
            });
        });
        </script>
        <?php
    }

    public function page_settings() {
        ?>
        <div class="wrap bz-wrap">
            <h1>BiztoriBD Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('biztoribbd_settings'); ?>
                <table class="form-table">
                    <tr>
                        <th>API Key</th>
                        <td><input type="password" name="biztoribbd_api_key" value="<?php echo esc_attr($this->api_key); ?>" class="regular-text">
                        <p class="description">Your BiztoriBD API key (starts with bz_). Get it from your <a href="https://biztoribbd.com/api-keys" target="_blank">account dashboard</a>.</p></td>
                    </tr>
                    <tr>
                        <th>API URL</th>
                        <td><input type="url" name="biztoribbd_api_url" value="<?php echo esc_attr($this->api_url); ?>" class="regular-text">
                        <p class="description">Only change if using a self-hosted instance.</p></td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    // ─── AJAX Handlers ───
    public function ajax_list_workflows() {
        check_ajax_referer('biztoribbd_nonce');
        $result = $this->api_get('/workflows');
        wp_send_json_success($result['data'] ?? []);
    }

    public function ajax_execute_workflow() {
        check_ajax_referer('biztoribbd_nonce');
        $wf_id = sanitize_text_field($_POST['workflow_id'] ?? '');
        $input = json_decode(stripslashes($_POST['input'] ?? '{}'), true);
        $result = $this->api_post('/workflows/' . $wf_id . '/execute', ['input' => $input]);
        if (isset($result['error'])) wp_send_json_error($result['error']);
        wp_send_json_success($result);
    }

    public function ajax_list_executions() {
        check_ajax_referer('biztoribbd_nonce');
        $result = $this->api_get('/executions?limit=50');
        wp_send_json_success($result['data'] ?? []);
    }

    public function ajax_get_execution() {
        check_ajax_referer('biztoribbd_nonce');
        $exec_id = sanitize_text_field($_POST['execution_id'] ?? '');
        $result = $this->api_get('/executions/' . $exec_id);
        wp_send_json_success($result);
    }

    public function ajax_workflow_stats() {
        check_ajax_referer('biztoribbd_nonce');
        $result = $this->api_get('/stats');
        wp_send_json_success($result);
    }

    public function ajax_save_mappings() {
        check_ajax_referer('biztoribbd_nonce');
        $mappings = json_decode(stripslashes($_POST['mappings'] ?? '{}'), true);
        update_option('biztoribbd_event_mappings', $mappings);
        wp_send_json_success('Saved');
    }

    // ─── WooCommerce Event Handlers ───
    public function on_new_order($order_id, $order = null) {
        if (!$order) $order = wc_get_order($order_id);
        if (!$order) return;
        $items = [];
        foreach ($order->get_items() as $item) {
            $items[] = [
                'product_id' => $item->get_product_id(),
                'name'       => $item->get_name(),
                'quantity'   => $item->get_quantity(),
                'total'      => $item->get_total(),
            ];
        }
        $this->trigger_mapped_workflow('new_order', [
            'order_id'       => $order_id,
            'status'         => $order->get_status(),
            'total'          => $order->get_total(),
            'currency'       => $order->get_currency(),
            'customer_email' => $order->get_billing_email(),
            'customer_name'  => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            'customer_phone' => $order->get_billing_phone(),
            'items'          => $items,
            'payment_method' => $order->get_payment_method_title(),
        ]);
    }

    public function on_order_complete($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;
        $this->trigger_mapped_workflow('order_complete', [
            'order_id'       => $order_id,
            'total'          => $order->get_total(),
            'customer_email' => $order->get_billing_email(),
            'customer_name'  => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
        ]);
    }

    public function on_payment_failed($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;
        $this->trigger_mapped_workflow('payment_failed', [
            'order_id'       => $order_id,
            'total'          => $order->get_total(),
            'customer_email' => $order->get_billing_email(),
            'error'          => $order->get_meta('_payment_error') ?: 'Payment declined',
        ]);
    }

    public function on_order_cancelled($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;
        $this->trigger_mapped_workflow('order_cancelled', [
            'order_id'       => $order_id,
            'total'          => $order->get_total(),
            'customer_email' => $order->get_billing_email(),
            'reason'         => $order->get_meta('_cancelled_reason') ?: '',
        ]);
    }

    public function on_order_refunded($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;
        $this->trigger_mapped_workflow('order_refunded', [
            'order_id'        => $order_id,
            'total'           => $order->get_total(),
            'refund_amount'   => $order->get_total_refunded(),
            'customer_email'  => $order->get_billing_email(),
        ]);
    }

    public function on_customer_created($customer_id, $new_customer_data, $password_generated) {
        $customer = new WC_Customer($customer_id);
        $this->trigger_mapped_workflow('customer_created', [
            'customer_id' => $customer_id,
            'email'       => $customer->get_email(),
            'first_name'  => $customer->get_first_name(),
            'last_name'   => $customer->get_last_name(),
        ]);
        // Sync contact
        $this->api_post('/contacts', [
            'email'      => $customer->get_email(),
            'first_name' => $customer->get_first_name(),
            'last_name'  => $customer->get_last_name(),
            'source'     => 'woocommerce',
        ]);
    }

    public function on_product_updated($product_id, $product = null) {
        if (!$product) $product = wc_get_product($product_id);
        if (!$product) return;
        $this->trigger_mapped_workflow('product_updated', [
            'product_id' => $product_id,
            'name'       => $product->get_name(),
            'price'      => $product->get_price(),
            'stock'      => $product->get_stock_quantity(),
            'status'     => $product->get_status(),
        ]);
    }

    public function on_add_to_cart($cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data) {
        $this->trigger_mapped_workflow('add_to_cart', [
            'product_id'   => $product_id,
            'variation_id' => $variation_id,
            'quantity'     => $quantity,
            'customer_email' => is_user_logged_in() ? wp_get_current_user()->user_email : null,
        ]);
    }

    // ─── Abandoned Cart ───
    public function check_abandoned_carts() {
        global $wpdb;
        $sessions = $wpdb->get_results(
            "SELECT session_key, session_value FROM {$wpdb->prefix}woocommerce_sessions WHERE session_expiry > " . time()
        );
        foreach ($sessions as $session) {
            $data = maybe_unserialize($session->session_value);
            if (empty($data['cart']) || empty($data['customer'])) continue;
            $cart = maybe_unserialize($data['cart']);
            $customer = maybe_unserialize($data['customer']);
            if (empty($cart) || empty($customer['email'])) continue;
            $transient_key = 'bz_abandon_' . md5($customer['email']);
            if (get_transient($transient_key)) continue;
            set_transient($transient_key, true, 6 * HOUR_IN_SECONDS);
            $items = [];
            foreach ($cart as $item) {
                $product = wc_get_product($item['product_id']);
                if ($product) {
                    $items[] = [
                        'product_id' => $item['product_id'],
                        'name'       => $product->get_name(),
                        'quantity'   => $item['quantity'],
                        'price'      => $product->get_price(),
                    ];
                }
            }
            $this->trigger_mapped_workflow('cart_abandon', [
                'email' => $customer['email'],
                'items' => $items,
                'cart_total' => array_sum(array_column($items, 'price')),
            ]);
        }
    }

    // ─── Tracker Script ───
    public function inject_tracker_script() {
        ?>
        <script>
        (function() {
            var BZ_KEY = "<?php echo esc_js($this->api_key); ?>";
            var BZ_URL = "<?php echo esc_js($this->api_url); ?>";
            var BZ = {
                post: function(ep, d) {
                    fetch(BZ_URL + ep, { method: "POST", headers: { "x-api-key": BZ_KEY, "Content-Type": "application/json" }, body: JSON.stringify(d) }).catch(function(){});
                },
                init: function() {
                    this.post("/track/pageview", { page_url: location.href, referrer: document.referrer });
                    <?php if (is_user_logged_in()): ?>
                    this.post("/contacts", { email: "<?php echo esc_js(wp_get_current_user()->user_email); ?>", source: "woocommerce" });
                    <?php endif; ?>
                }
            };
            window.addEventListener("load", function() { BZ.init(); });
        })();
        </script>
        <?php
    }

    // ─── Core API Methods ───
    private function trigger_mapped_workflow($event_key, $input_data) {
        $mappings = get_option('biztoribbd_event_mappings', []);
        if (!is_array($mappings) || empty($mappings[$event_key])) return;
        $this->api_post('/workflows/' . $mappings[$event_key] . '/execute', [
            'input' => array_merge($input_data, [
                '_source'    => 'wordpress',
                '_event'     => $event_key,
                '_timestamp' => current_time('c'),
                '_site_url'  => home_url(),
            ]),
        ]);
    }

    private function api_get($endpoint) {
        $response = wp_remote_get($this->api_url . $endpoint, [
            'headers' => ['x-api-key' => $this->api_key],
            'timeout' => 30,
        ]);
        if (is_wp_error($response)) return ['error' => $response->get_error_message()];
        return json_decode(wp_remote_retrieve_body($response), true);
    }

    private function api_post($endpoint, $data) {
        $response = wp_remote_post($this->api_url . $endpoint, [
            'headers' => ['x-api-key' => $this->api_key, 'Content-Type' => 'application/json'],
            'body'    => json_encode($data),
            'timeout' => 30,
        ]);
        if (is_wp_error($response)) return ['error' => $response->get_error_message()];
        return json_decode(wp_remote_retrieve_body($response), true);
    }
}

new BiztoriBD_Automation();
